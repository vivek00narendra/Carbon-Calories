
let bgpage = chrome.extension.getBackgroundPage();

let items = bgpage.items
let images = bgpage.itemsImg
let user = bgpage.user
let scores = bgpage.itemScores
let itemNames = bgpage.itemNames
let overallScore = 10
let loggedIn = bgpage.loggedIn
let logInButton = document.getElementsByClassName("Log in")

if(loggedIn == true){
    console.log(logInButton[0])
    document.getElementsByClassName("Log in")[0].innerHTML = user.username
    logInButton[0].setAttribute("href","https://carbon-calories.nn.r.appspot.com/login")
}

console.log(images.length)    
console.log(images[0])
console.log(images[0].backgroundImage.length)

container = document.getElementsByClassName("items")
for (var i = 0; i < images.length; i++){

    
    itemRow = document.createElement("div")
    itemRow.setAttribute("class", "itemScoreRow")

    img = document.createElement('img')
    img.setAttribute("class","itemImg")
    img.setAttribute("style", "padding:1% 2%")
    img.src = images[i].backgroundImage.substring(5,images[i].backgroundImage.length - 2)
    itemRow.appendChild(img)

    rowText = document.createElement("div")

    itemName = document.createElement("h1")
    console.log(itemNames[i])
    nameText = itemNames[i]
    itemName.innerHTML = nameText
    rowText.appendChild(itemName)

    itemScore = document.createElement("h1")
    scoreText = "Rating: <strong>" + scores[i].toFixed(1) + "</strong>"
    itemScore.innerHTML = scoreText
    rowText.appendChild(itemScore)

    
    itemRow.appendChild(rowText)
    container[0].appendChild(itemRow)
    

}
var bottomBar = document.createElement('div')
bottomBar.setAttribute("class","bottomBar")
var OvrScore = document.createElement('p')
calculateOverallScore()
OvrScore.innerHTML = "Overall Rating: <strong>" + overallScore.toFixed(1) + "</strong>"
bottomBar.appendChild(OvrScore)
container[0].appendChild(bottomBar)
console.log("overallScore is " + overallScore)



function calculateOverallScore(){
    scoreTotal = 0
    for (var i = 0; i < scores.length; i++){
        scoreTotal += scores[i]
        console.log(scores[i])
    }
    scoreTotal = scoreTotal/ scores.length
    overallScore = scoreTotal
}





    